import numpy as np
import networkx as nx
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

# --- FUNÇÃO PARA LER A MATRIZ DO ARQUIVO E SUBSTITUIR -1 POR 0 ---
def ler_matriz_de_arquivo(nome_arquivo):
    with open(nome_arquivo, 'r') as f:
        linhas = f.readlines()
        matriz = []
        for linha in linhas:
            linha = linha.strip()
            if linha:
                # Substitui -1 por 0 (sem aresta)
                numeros = [float(x) if float(x) >= 0 else 0 for x in linha.split()]
                matriz.append(numeros)
    return np.array(matriz)

# --- LÊ A MATRIZ ---
matriz = ler_matriz_de_arquivo("matriz.txt")

# --- CRIA O GRAFO ---
G = nx.from_numpy_array(matriz)

# --- POSIÇÕES COM BASE NO PESO (nós mais conectados mais centrais) ---
pos = nx.spring_layout(G, seed=42, weight='weight')

# --- DESENHO ---
plt.figure(figsize=(12, 10))
nx.draw_networkx_nodes(G, pos, node_color='lightgreen', node_size=800)
nx.draw_networkx_labels(G, pos, font_weight='bold')

# Arestas com espessura proporcional ao peso
pesos = [d['weight'] for (_, _, d) in G.edges(data=True)]
pesos_normalizados = [w / max(pesos) * 8 for w in pesos]
nx.draw_networkx_edges(G, pos, width=pesos_normalizados, edge_color='black')

# --- LEGENDA DOS NÓS ---
legenda = {
    0: "0 = Arya",
    1: "1 = Bran",
    2: "2 = Brienne",
    3: "3 = Catelyn",
    4: "4 = Cersei",
    5: "5 = Jaime",
    6: "6 = Robert",
    7: "7 = Sansa",
    8: "8 = Tyrion",
    9: "9 = Varys"
}
texto_legenda = "\n".join(legenda.values())
plt.figtext(0.01, 0.02, texto_legenda, ha='left', va='bottom', fontsize=18, family='monospace')

plt.title("Grafo com arestas proporcionais ao peso", fontsize=16)
plt.axis('off')
plt.tight_layout()
plt.show()
