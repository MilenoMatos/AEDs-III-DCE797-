/*
 * Trabalho 3 | AEDS III
 *
 * Nomes: Enzo Maranezi                     2024.1.08.008
 *        Guilherme Oliveira Araújo         2024.1.08.011
 *        Isabella Cristina da Silveira     2019.2.08.004
 *        João Pedro Carvalho Ferreira      2024.1.08.030
 *        Luis Renato Goulart               2023.1.08.049
 *        Mileno Oliveira Matos             2021.1.08.051
 *          
 * Descrição: Projeto para ler um livro e montar um grafo com 10 vértices, sendo cada um,
 *            representando uma personagem. Cada vez que 2 destes personagens aparecem a
 *            uma distância de no máximo 100 palavras, o peso da aresta entre elas é
 *            incrementada em uma unidade. Ao final da leitura, são calculados o betweeness,
 *            para cada personagem, e o circuit rank do grafo. São exibidos as 10 personagens,
 *            dos mais centrais para os menos centrais, do grafo. Além disso, também é
 *            escrito um arquivo, contendo o grafo, para ser processado por um código da
 *            linguagem Python, que exibe a rede na tela.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "trabalho_3.h"

// Retorna um valor entre 0 e 10 se palavra for uma personagem e -1, caso contrário
int ehPersonagem(char *palavra){
    int i = 0;

    while ((palavra[i] < 'a' || palavra[i] > 'z') &&
           (palavra[i] < 'A' || palavra[i] > 'V') &&
           palavra[i] != '\0')  // Percorre a palavra até encontrar uma letra minúscula ou maiúscula 
        i++;

    if ((palavra[i] >= 'a' && palavra[i] <= 'z') || palavra[i] == '\0')
        return -1;
    else
        switch (palavra[i]){
            case 'A':
                if (strstr(palavra, "Arya") != NULL) return 0;
            case 'B':
                if (strstr(palavra, "Bran") != NULL) return 1;
                else if (strstr(palavra, "Brienne") != NULL) return 2;
            case 'C':
                if (strstr(palavra, "Catelyn") != NULL) return 3;
                else if (strstr(palavra, "Cersei") != NULL) return 4;
            case 'J':
                if (strstr(palavra, "Jaime") != NULL) return 5;
            case 'R':
                if (strstr(palavra, "Robert")) return 6;
            case 'S':
                if (strstr(palavra, "Sansa") != NULL) return 7;
            case 'T':
                if (strstr(palavra, "Tyrion") != NULL) return 8;
            case 'V':
                if (strstr(palavra, "Varys") != NULL) return 9;
            default:
                return -1;
        }
}

// Peenche a fila com as 102 primeiras palavras do livro 
void preencheFila(FILE *livro, int *fila, int *qtdPersonagensFila){
    char tmp[TAM_MAX_DE_PALAVRA];  // Amazena a palavra lida até que seja verificada se é uma personagem
    int novoPersonagem;

    for (int i = 0; i < DIST_MAX_ENTRE_PERSONAGENS + 2; i++){  // Percorre as 102 primeiras palavras 
        fscanf(livro, "%s", tmp);
        novoPersonagem = ehPersonagem(tmp);
        if (novoPersonagem != -1)  // Verifica se novoPersonagem é realmente uma personagem 
            qtdPersonagensFila[novoPersonagem]++; // Se for, incrementa a quantidade da mesma na fila 
        fila[i] = novoPersonagem;  // Coloca na fila 
    }
}

// Incrementa as relações de uma personagem com as demais que estão na fila 
void insereRelacoes(Grafo G, int personagem, int *qtdPersonagensFila){
    for (int i = 0; i < QTD_VERTICES; i++)
        if (personagem != i && qtdPersonagensFila[i] > 0){
            G[personagem][i]++;
            G[i][personagem]++;
        }
}

// Esvazia a fila após terminar a leitura do livro
void esvaziaFila(int *fila, int indicePrimeiroPersonagem, int *qtdPersonagensFila, Grafo G){
    int personagemMaisDistante = fila[indicePrimeiroPersonagem];
    int fim = indicePrimeiroPersonagem;
    
    if (personagemMaisDistante != -1){  // Verifica se personagemMaisDistante é realmente uma personagem
        insereRelacoes(G, personagemMaisDistante, qtdPersonagensFila);  // Se for, insere suas relações no grafo com demais que ainda estão na fila
        qtdPersonagensFila[personagemMaisDistante]--;  // Diminui, em uma unidade, a quantidade de ocorrência da mesma na fila 
    }

    indicePrimeiroPersonagem = (indicePrimeiroPersonagem + 1) % (DIST_MAX_ENTRE_PERSONAGENS + 2);  // Encontra o próximo personagem na fila 

    while (indicePrimeiroPersonagem != fim){  // Enquanto a fila não estiver fazia, é realizado processo análogo ao anterior
        personagemMaisDistante = fila[indicePrimeiroPersonagem]; 
        if (personagemMaisDistante != -1){  
            insereRelacoes(G, personagemMaisDistante, qtdPersonagensFila);
            qtdPersonagensFila[personagemMaisDistante]--;
        }
        indicePrimeiroPersonagem = (indicePrimeiroPersonagem + 1) % (DIST_MAX_ENTRE_PERSONAGENS + 2);
    }
}

void leLivro(FILE *livro, Grafo G){
    int fila[DIST_MAX_ENTRE_PERSONAGENS + 2];  // Fila circular que armazena os números relativo a cada personagem e -1 para as demais palavras, numa janela de 102 palavras
    int qtdPersonagensFila[QTD_VERTICES] = {0};  // Array que armazena a quantidade de cada personagem na fila

    preencheFila(livro, fila, qtdPersonagensFila); // Preenche a fila com as 102 primeiras palavras do livro

    char tmp[TAM_MAX_DE_PALAVRA];  // Amazena a palavra lida até que seja verificada se é uma personagem
    int novoPersonagem;   // Armazena a primeira personagem da fila 
    int personagemMaisDistante; // Armazena a última personagem da fila 
    int indicePrimeiroPersonagem = 0;  // Armazena o índice da primeira personagem na fila 

    while (fscanf(livro, "%s", tmp) != EOF){  // Enquanto não chegar ao fim do livro 
        personagemMaisDistante = fila[indicePrimeiroPersonagem]; // Retira a última personagem da fila
        if (personagemMaisDistante != -1){  // Verifica se personagemMaisDistante é realmente uma personagem
            insereRelacoes(G, personagemMaisDistante, qtdPersonagensFila);  // Se for, insere suas relações no grafo com demais que ainda estão na fila
            qtdPersonagensFila[personagemMaisDistante]--;  // E diminui, em uma unidade, a quantidade de ocorrência da mesma na fila
        }

        novoPersonagem = ehPersonagem(tmp);  
        if (novoPersonagem != -1)  // Verifica se novoPersonagem é realmente uma personagem 
            qtdPersonagensFila[novoPersonagem]++;  // Se for, incrementa a quantidade da mesma na fila
        fila[indicePrimeiroPersonagem] = novoPersonagem;  // Sobrescreve a última personagem que foi retirada da fila anteriormente

        indicePrimeiroPersonagem = (indicePrimeiroPersonagem + 1) % (DIST_MAX_ENTRE_PERSONAGENS + 2);  // Encontra a posição da próxima personagem a ser retirada da fila
    }
    
    esvaziaFila(fila, indicePrimeiroPersonagem, qtdPersonagensFila, G); // Processa as últimas 102 palavras que ainda estão na fila 
}

// Copia o conteúdo do grafo G1 para o G2, atribuindo -1 entre dois vértices que não apresenta aresta entre eles 
void copiaGrafoEAnulaArestas(Grafo G1, Grafo G2){
    for (int i = 0; i < QTD_VERTICES; i++)
        for (int j = 0; j < QTD_VERTICES; j++)
            if (G1[i][j] != 0 || i == j)
                G2[i][j] = G1[i][j];
            else
                G2[i][j] = -1;
}

// Retorna o maior peso de todas as aresta do grafo 
int obtemMaiorPeso(Grafo G){
    int maiorPeso = INT_MIN;

    for (int i = 0; i < QTD_VERTICES; i++)
        for (int j = 0; j < QTD_VERTICES; j++)
            if (G[i][j] > maiorPeso)
                maiorPeso = G[i][j];

    return maiorPeso;
}

// Inverte, proporcionalmente, os pesos das arestas do grafo e atribui -1 entre dois vértices que não apresenta aresta entre eles 
void invertePesosEAnulaArestas(Grafo G){
    int maiorPeso = obtemMaiorPeso(G);

    for (int i = 0; i < QTD_VERTICES; i++)
        for (int j = 0; j < QTD_VERTICES; j++)
            if (i != j){
                if (G[i][j] > 0)
                    G[i][j] = maiorPeso - G[i][j];
                else
                    G[i][j] = -1;
            }
}

// Função recursiva que reconstrói todos os caminhos mínimos do destino até a origem usando DFS reversa
void dfsReconstroiCaminhos(int atual, int profundidade, int predecessores[][QTD_VERTICES],
                           int *qtdPredecessores, int inicio, int caminhos[][QTD_VERTICES],
                           int *tamCaminhos, int *pilha, int *qtdCaminhos){
    if (profundidade >= QTD_VERTICES) // Limita profundidade para evitar estouro
        return;

    pilha[profundidade] = atual; // Armazena o vértice atual na pilha

    if (atual == inicio){ // Caminho completo do fim até o início encontrado
        if (*qtdCaminhos >= QTD_MAX_CAMINHOS_MINIMOS) // Limita a quantidade de caminhos armazenados
            return;
        
        for (int i = 0; i <= profundidade; i++)  // Salva o caminho na ordem correta
            caminhos[*qtdCaminhos][i] = pilha[profundidade - i]; // Inverte o caminho ao salvar
        tamCaminhos[*qtdCaminhos] = profundidade + 1; // Salva o tamanho do caminho
        (*qtdCaminhos)++;// Incrementa o número de caminhos encontrados
        return;
    }

    for (int i = 0; i < qtdPredecessores[atual]; i++) // Explora todos os predecessores do vértice atual
        dfsReconstroiCaminhos(predecessores[atual][i], profundidade + 1, predecessores,
                              qtdPredecessores, inicio, caminhos, tamCaminhos, pilha,
                              qtdCaminhos);
}

// Executa o algoritmo de Dijkstra e retorna todos os caminhos mínimos entre dois vértices
int dijkstraMultiplosCaminhosMinimos(Grafo G, int inicio, int fim, int caminhos[][QTD_VERTICES],
                                     int *tamCaminhos){
    int dist[QTD_VERTICES]; // Array de distâncias mínimas a partir do vértice inicial
    int visitado[QTD_VERTICES] = {0}; // Marca vértices já processados
    int predecessores[QTD_VERTICES][QTD_VERTICES]; // predecessores[v] = lista de vértices que precedem v nos caminhos mínimos
    int qtdPredecessores[QTD_VERTICES] = {0}; // Número de predecessores para cada vértice

    for (int i = 0; i < QTD_VERTICES; i++){  // Inicializa distâncias e predecessores
        dist[i] = INT_MAX;
        for (int j = 0; j < QTD_VERTICES; j++)
            predecessores[i][j] = -1;
    }

    dist[inicio] = 0; // Distância do início para ele mesmo é zero
    int min;
    int u;
    int novaDist;

    for (int cont = 0; cont < QTD_VERTICES; cont++){ // Laço principal do Dijkstra (QTD_VERTICES iterações)
        min = INT_MAX;
        u = -1;
        for (int i = 0; i < QTD_VERTICES; i++) // Encontra o vértice não visitado com menor distância
            if (!visitado[i] && dist[i] < min){
                min = dist[i];
                u = i;
            }

        if (u == -1) // Se não há mais vértices alcançáveis
            break;

        visitado[u] = 1; // Marca vértice atual como visitado
        for (int v = 0; v < QTD_VERTICES; v++)  // Verifica todos os vizinhos de u
            if (G[u][v] != -1){   // Se há aresta entre u e v
                novaDist = dist[u] + G[u][v];
                if (novaDist < dist[v]){ // Encontrou caminho mais curto para v
                    dist[v] = novaDist;
                    qtdPredecessores[v] = 0;
                    predecessores[v][qtdPredecessores[v]++] = u;  // Atualiza predecessores
                }
                else if (novaDist == dist[v]) // Encontrou outro caminho mínimo para v
                    predecessores[v][qtdPredecessores[v]++] = u;  // Adiciona novo predecessor
            }
    }

    if (dist[fim] == INT_MAX) // Não há caminho entre início e fim
        return 0;

    int pilha[QTD_VERTICES]; // Pilha para armazenar caminho atual
    int qtdCaminhos = 0;

    dfsReconstroiCaminhos(fim, 0, predecessores, qtdPredecessores, inicio, caminhos,
                          tamCaminhos, pilha, &qtdCaminhos); // Reconstrói todos os caminhos mínimos usando DFS reversa

    return qtdCaminhos; // Retorna a quantidade de caminhos mínimos encontrados
}


// Calcula o betweeness de cada vértice do grafo 
void calculaBetweeness(double *betweenessVertices, Grafo G){
    int qtdCaminhosMinimos;  // Quantidade de caminhos mínimos entre dois vértices 
    int caminhos[QTD_MAX_CAMINHOS_MINIMOS][QTD_VERTICES];  // Matriz que armazena os caminhos mínimos entre dois vértices
    int *caminhoAnalizado;  // Ponteiro que armazena um array com o caminho em análise 
    int integranteCaminho; // Armazena um vértice do caminho em análise 
    int tamCaminhos[QTD_MAX_CAMINHOS_MINIMOS]; // Armazena o tamanho de cada caminho da matriz 
    
    for (int inicio = 0; inicio < QTD_VERTICES; inicio++)
        for (int fim = 0; fim < QTD_VERTICES; fim++){  // Para todos os pares de vértices do grafo 

            if (inicio == fim)  // Se os vértices inicial e final forem iguais, ignora esse par 
                continue;

            qtdCaminhosMinimos = dijkstraMultiplosCaminhosMinimos(G, inicio, fim, caminhos,
                                                                  tamCaminhos);
            for (int caminho = 0; caminho < qtdCaminhosMinimos; caminho++){  // Para cada caminho mínimo 
                caminhoAnalizado = caminhos[caminho];
                for (int i = 0; i < tamCaminhos[caminho]; i++){  // Para cada vértice do caminho 
                    integranteCaminho = caminhoAnalizado[i];
                    if (integranteCaminho != inicio && integranteCaminho != fim)  // Se ele for diferente do vértice inicial e final do caminho 
                        betweenessVertices[integranteCaminho] += (1.0 / qtdCaminhosMinimos); // Então, é alterado seu betweeness
                }
            }
        }
}

// Obtem os nomes de cada personagem de acordo com os índices de 0 a 9
void obtemNomesPersonagens(Personagem *personagens){
    for (int i = 0; i < QTD_VERTICES; i++)
        switch (i){
                case 0:
                    strcpy(personagens[i].nome, "Arya");
                    break;
                case 1:
                    strcpy(personagens[i].nome, "Bran");
                    break;
                case 2:
                    strcpy(personagens[i].nome, "Brienne");
                    break;
                case 3:
                    strcpy(personagens[i].nome, "Catelyn");
                    break;
                case 4:
                    strcpy(personagens[i].nome, "Cersei");
                    break;
                case 5:
                    strcpy(personagens[i].nome, "Jaime");
                    break;
                case 6:
                    strcpy(personagens[i].nome, "Robert");
                    break;
                case 7:
                    strcpy(personagens[i].nome, "Sansa");
                    break;
                case 8:
                    strcpy(personagens[i].nome, "Tyrion");
                    break;
                case 9:
                    strcpy(personagens[i].nome, "Varys");
                    break;
        }
}

// Escreve a rede, antes da inversão dos pesos, em um arquivo.
void escreveRede(FILE *arquivoRede, Grafo Rede){
    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10; j++)
            fprintf(arquivoRede, "%d ", Rede[i][j]);
        fprintf(arquivoRede, "\n");
    }
}

// Encontra o pivô do array de personagem, com relação ao campo betweeness
double particiona(Personagem *arr, int inicio, int fim){
    Personagem tmp;
    Personagem pivo = arr[fim];
    int i = inicio - 1;

    for (int j = inicio; j < fim; j++){
        if (arr[j].betweeness <= pivo.betweeness){
            i++;
            tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
    }

    i++;
    arr[fim] = arr[i];
    arr[i] = pivo;

    return i;
}

// Particiona o array de personagens em duas partes, tendo como base o pivô 
void quickSort(Personagem *arr, int inicio, int fim){
    if (inicio < fim){
        int pivo = particiona(arr, inicio, fim);

        quickSort(arr, inicio, pivo - 1);
        quickSort(arr, pivo + 1, fim);
    }
}

// Exibe os personagens na tela. Dos mais centrais para os menos centrais, considerando o betweeness
void exibePersonagens(double *betweenessVertices, Personagem *personagens){
    for (int i = 0; i < QTD_VERTICES; i++)
        personagens[i].betweeness = betweenessVertices[i];

    quickSort(personagens, 0, QTD_VERTICES - 1);

    puts(" Os dez personages do livro, dos mais centrais para os menos centrais, são:");
    for (int i = QTD_VERTICES - 1; i >= 0; i--)
        printf(" %dº %s.\n", (QTD_VERTICES - i), personagens[i].nome);
}

// Retorna o número de arestas do grafo 
int contaArestas(Grafo G){
    int qtdArestas = 0;

    for (int i = 0; i < QTD_VERTICES; i++)
        for (int j = i + 1; j < QTD_VERTICES; j++) // não conta duas vezes a mesma aresta
            if (G[i][j] != -1)
                qtdArestas++;

    return qtdArestas;
}

// Realiza busca em profundidade (DFS) a partir de um vértice, marcando todos os vértices alcançáveis
void dfs(Grafo G, int *visitado, int vertice){
    visitado[vertice] = 1; // Marca o vértice atual como visitado

    for (int v = 0; v < QTD_VERTICES; v++) // Percorre todos os vértices do grafo
        if (G[vertice][v] != -1 && !visitado[v]) // Se há aresta entre os vértices e o vizinho ainda não foi visitado
            dfs(G, visitado, v);  // Realiza DFS recursivamente no vizinho
}

// Retorna a quantidade de componentes conexos do grafo
int contaComponentesConexos(Grafo G){
    int visitado[QTD_VERTICES] = {0}; // Array de marcação para vértices visitados, inicializado com 0
    int qtdComponentes = 0;  // Contador de componentes conexos

    for (int i = 0; i < QTD_VERTICES; i++) // Percorre todos os vértices do grafo
        if (!visitado[i]){  // Se o vértice ainda não foi visitado
            dfs(G, visitado, i);  // Inicia DFS a partir desse vértice
            qtdComponentes++;  // Incrementa o número de componentes conexos
        }

    return qtdComponentes;  // Retorna o total de componentes encontrados
}


// Calcula e exibe o circuit rank do grafo 
void calculaEExibeCircuitRank(Grafo G){
    int qtdArestas = contaArestas(G);
    int qtdComponentes = contaComponentesConexos(G);

    int circuitRank = qtdArestas - QTD_VERTICES + qtdComponentes;

    printf(" O circuit rank do grafo é %d.\n", circuitRank);
}

int main(){
    FILE *livro = fopen("A-Storm-of-Swords.txt", "r");

    if (livro == NULL){
        puts("ERRO: Arquivo não encontrado");
        return 1;
    }

    Grafo G = {0};

    leLivro(livro, G);

    fclose(livro);

    Grafo Rede;

    copiaGrafoEAnulaArestas(G, Rede);

    invertePesosEAnulaArestas(G);

    double betweenessVertices[QTD_VERTICES] = {0.0};

    calculaBetweeness(betweenessVertices, G);

    Personagem personagens[QTD_VERTICES];

    obtemNomesPersonagens(personagens);

    FILE *arquivoRede = fopen("./rede/matriz.txt", "w");

    if (arquivoRede == NULL){
        puts("ERRO: Arquivo não encontrado");
        return 2;
    }

    escreveRede(arquivoRede, Rede);

    exibePersonagens(betweenessVertices, personagens);

    puts("");

    calculaEExibeCircuitRank(G);

    return 0;
}