/*
 * Trabalho 3 | AEDS III
 *
 * Nomes: Enzo Maranezi                     2024.1.08.008
 *        Guilherme Oliveira Araújo         2024.1.08.011
 *        Isabella Cristina da Silveira     2019.2.08.004
 *        João Pedro Carvalho Ferreira      2024.1.08.030
 *        Luis Renato Goulart               2023.1.08.049
 *        Mileno Oliveira Matos             2021.1.08.051
 *          
 * Descrição: Projeto para ler um livro e montar um grafo com 10 vértices, sendo cada um,
 *            representando uma personagem. Cada vez que 2 destes personagens aparecem a
 *            uma distância de no máximo 100 palavras, o peso da aresta entre elas é
 *            incrementada em uma unidade. Ao final da leitura, são calculados o betweeness,
 *            para cada personagem, e o circuit rank do grafo. São exibidos as 10 personagens,
 *            dos mais centrais para os menos centrais, do grafo. Além disso, também é
 *            escrito um arquivo, contendo o grafo, para ser processado por um código da
 *            linguagem Python, que exibe a rede na tela.
 * 
 */

#ifndef _H_TRABALHO_3
#define _H_TRABALHO_3

#define QTD_VERTICES 10 // Número de vértices do grafo

#define TAM_MAX_DE_PALAVRA 64 // Tamanho máximo de uma palavra do livro

#define DIST_MAX_ENTRE_PERSONAGENS 100  // Distância (em palavras) para se considerar uma relação entre duas personagens

#define QTD_MAX_CAMINHOS_MINIMOS 1000   // Quantidade máxima de caminhos mínimos permitida entre dois vértices 

typedef int Grafo[QTD_VERTICES][QTD_VERTICES];  // Estrutura de dados (matriz de adjacência) para representar o grafo

typedef struct{
    char nome[TAM_MAX_DE_PALAVRA];
    double betweeness;
}Personagem;  // Estrutura de dados para representar uma personagem

int ehPersonagem(char *palavra);

void preencheFila(FILE *livro, int *fila, int *qtdPersonagensFila);

void insereRelacoes(Grafo G, int personagem, int *qtdPersonagensFila);

void esvaziaFila(int *fila, int indicePrimeiroPersonagem, int *qtdPersonagensFila, Grafo G);

void leLivro(FILE *livro, Grafo G);

void copiaGrafoEAnulaArestas(Grafo G1, Grafo G2);

int obtemMaiorPeso(Grafo G);

void invertePesosEAnulaArestas(Grafo G);

void dfsReconstroiCaminhos(int atual, int profundidade, int predecessores[][QTD_VERTICES],
                           int *qtdPredecessores, int inicio, int caminhos[][QTD_VERTICES],
                           int *tamCaminhos, int *pilha, int *qtdCaminhos);
                           
int dijkstraMultiplosCaminhosMinimos(Grafo G, int inicio, int fim, int caminhos[][QTD_VERTICES],
                                     int *tamCaminhos);
                                    
void calculaBetweeness(double *betweenessVertices, Grafo G);

void obtemNomesPersonagens(Personagem *personagens);

void escreveRede(FILE *arquivoRede, Grafo Rede);

double particiona(Personagem *arr, int inicio, int fim);

void quickSort(Personagem *arr, int inicio, int fim);

void exibePersonagens(double *betweenessVertices, Personagem *personagens);

int contaArestas(Grafo G);

void dfs(Grafo G, int *visitado, int vertice);

int contaComponentesConexos(Grafo G);

void calculaEExibeCircuitRank(Grafo G);

#endif
